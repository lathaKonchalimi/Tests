package info.seleniumcucumber.userStepDefintions;
import cucumber.api.java.en.Then;
import env.DriverUtil;
import info.seleniumcucumber.methods.BaseTest;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated;


public class UserStepDefinitions implements BaseTest {
	
	protected WebDriver driver = DriverUtil.getDefaultDriver();

	@Then("^I should see correct title$")
	public void should_see_correct_title() throws Throwable {
		String xpath = "//div[@id='dlg-dealersearch-title']";

		By selection = By.xpath(xpath);
		(new WebDriverWait(driver, 30)).until(
				visibilityOfElementLocated(selection));
		String msg = driver.findElement(By.xpath(xpath)).getText();
		if(!msg.isEmpty())
			msg = msg.split("\n")[0].trim();
		Assert.assertEquals("Drive Away Insurance", msg);
	}

    @Then("^I should see correct vehicle result$")
    public void should_see_correct_search_result() throws Throwable {
        String xpath = "//div[@class='result']";

        By selection = By.xpath(xpath);
        (new WebDriverWait(driver, 30)).until(
                visibilityOfElementLocated(selection));
        String msg = driver.findElement(By.xpath(xpath)).getText();
        if(!msg.isEmpty())
            msg = msg.split("\n")[0].trim();
        Assert.assertEquals("Result for : OV12UYY", msg);
    }

    @Then("^I should see Record not Found message$")
    public void should_see_correct_invalid_search_result() throws Throwable {
        String xpath = "//div[@class='result']";

        By selection = By.xpath(xpath);
        (new WebDriverWait(driver, 30)).until(
                visibilityOfElementLocated(selection));
        String msg = driver.findElement(By.xpath(xpath)).getText();
        if(!msg.isEmpty())
            msg = msg.split("\n")[0].trim();
        Assert.assertEquals("Sorry record not found", msg);
    }

    @Then("^I should see correct empty search error message$")
    public void should_see_correct_empty_search_result() throws Throwable {
        String xpath = "//div[@class='error-required']";

        By selection = By.xpath(xpath);
        (new WebDriverWait(driver, 30)).until(
                visibilityOfElementLocated(selection));
        String msg = driver.findElement(By.xpath(xpath)).getText();
        if(!msg.isEmpty())
            msg = msg.split("\n")[0].trim();
        Assert.assertEquals("Please enter a valid car registration", msg);
    }
}
